




package org.java;

public class Main {
    public static void main(String[] args) {
        // This redirects the execution to your JavaFX App class
        App.main(args);
    }
}