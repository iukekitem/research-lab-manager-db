package org.java;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class LabManagerDAO {
    private Connection conn;

    public LabManagerDAO(Connection conn) {
        this.conn = conn;
    }


    // Get all member IDs currently assigned to a project
    public List<Integer> getMemberIdsForProject(int projectId) throws SQLException {
        List<Integer> ids = new ArrayList<>();
        String sql = "SELECT MemberID FROM WorksOn WHERE ProjectID = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, projectId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    ids.add(rs.getInt("MemberID"));
                }
            }
        }
        return ids;
    }

    // Replace all WorksOn rows for a project with the given member list
    public void setProjectMembers(int projectId, List<Integer> memberIds) throws SQLException {
        // 1) Remove existing assignments
        String deleteSql = "DELETE FROM WorksOn WHERE ProjectID = ?";
        try (PreparedStatement stmt = conn.prepareStatement(deleteSql)) {
            stmt.setInt(1, projectId);
            stmt.executeUpdate();
        }

        // 2) Insert new assignments (skip null/duplicate IDs in the list)
        if (memberIds == null || memberIds.isEmpty()) {
            return; // no members for this project
        }

        String insertSql = "INSERT INTO WorksOn (MemberID, ProjectID) VALUES (?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(insertSql)) {
            for (Integer memberId : memberIds) {
                if (memberId == null) continue;
                stmt.setInt(1, memberId);
                stmt.setInt(2, projectId);
                stmt.addBatch();
            }
            stmt.executeBatch();
        }
    }



    public List<LabMember> listMembers() throws SQLException {
        List<LabMember> members = new ArrayList<>();
        String sql = "SELECT MemberID, FirstName, LastName, JoinDate FROM LabMembers";
        try (Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                LabMember m = new LabMember();
                m.setMemberId(rs.getInt("MemberID"));
                m.setFirstName(rs.getString("FirstName"));
                m.setLastName(rs.getString("LastName"));
                m.setJoinDate(rs.getString("JoinDate")); // or format Date -> String
                members.add(m);
            }
        }
        return members;
    }

    public int addMember(String firstName, String lastName, LocalDate joinDate) throws SQLException {
        String sql = "INSERT INTO LabMembers (FirstName, LastName, JoinDate) VALUES (?, ?, ?)";
        int memberId;

        try (PreparedStatement stmt = conn.prepareStatement(
                sql,
                Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, firstName);
            stmt.setString(2, lastName);
            stmt.setDate(3, Date.valueOf(joinDate));
            stmt.executeUpdate();

            try (ResultSet keys = stmt.getGeneratedKeys()) {
                if (!keys.next()) {
                    throw new SQLException("No MemberID generated");
                }
                memberId = keys.getInt(1);
            }
        }

        return memberId;
    }

    // Update an existing lab member
    public void updateMember(int memberId, String firstName, String lastName, LocalDate joinDate)
            throws SQLException {

        String sql = "UPDATE LabMembers " +
                    "SET FirstName = ?, LastName = ?, JoinDate = ? " +
                    "WHERE MemberID = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, firstName);
            stmt.setString(2, lastName);
            stmt.setDate(3, Date.valueOf(joinDate));
            stmt.setInt(4, memberId);
            stmt.executeUpdate();
        }
    }

    public void deleteMember(int memberId) throws SQLException {
    // Optional: clean up WorksOn and Uses first if not cascading
    String deleteWorksOn = "DELETE FROM WorksOn WHERE MemberID = ?";
    try (PreparedStatement stmt = conn.prepareStatement(deleteWorksOn)) {
        stmt.setInt(1, memberId);
        stmt.executeUpdate();
    }

    String deleteUses = "DELETE FROM Uses WHERE MemberID = ?";
    try (PreparedStatement stmt = conn.prepareStatement(deleteUses)) {
        stmt.setInt(1, memberId);
        stmt.executeUpdate();
    }

    String sql = "DELETE FROM LabMembers WHERE MemberID = ?";
    try (PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setInt(1, memberId);
        stmt.executeUpdate();
    }
}


    public List<ResearchProject> listProjects() throws SQLException {
        List<ResearchProject> projects = new ArrayList<>();

        String sql =
            "SELECT p.ProjectID, p.Title, p.Status, " +
            "       STRING_AGG(CAST(w.MemberID AS VARCHAR(20)), ',') WITHIN GROUP (ORDER BY w.MemberID) AS MemberIDs " +
            "FROM ResearchProjects p " +
            "LEFT JOIN WorksOn w ON p.ProjectID = w.ProjectID " +
            "GROUP BY p.ProjectID, p.Title, p.Status";

        try (Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                ResearchProject project = new ResearchProject();
                project.setProjectId(rs.getInt("ProjectID"));
                project.setTitle(rs.getString("Title"));
                project.setStatus(rs.getString("Status"));
                project.setMemberIds(rs.getString("MemberIDs")); // may be null if no members
                projects.add(project);
            }
        }
        return projects;
    }

    // Insert a new research project
    public int addProject(String title, String status) throws SQLException {
        String sql = "INSERT INTO ResearchProjects (Title, Status) VALUES (?, ?)";
        int projectId;

        try (PreparedStatement stmt = conn.prepareStatement(
                sql,
                Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, title);
            stmt.setString(2, status);
            stmt.executeUpdate();

            try (ResultSet keys = stmt.getGeneratedKeys()) {
                if (!keys.next()) {
                    throw new SQLException("No ProjectID generated");
                }
                projectId = keys.getInt(1);
            }
        }

        return projectId;
    }

    // Update an existing project
    public void updateProject(int projectId, String title, String status) throws SQLException {
        String sql = "UPDATE ResearchProjects " +
                    "SET Title = ?, Status = ? " +
                    "WHERE ProjectID = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, title);
            stmt.setString(2, status);
            stmt.setInt(3, projectId);
            stmt.executeUpdate();
        }
    }

    public void deleteProject(int projectId) throws SQLException {
    String deleteWorksOn = "DELETE FROM WorksOn WHERE ProjectID = ?";
    try (PreparedStatement stmt = conn.prepareStatement(deleteWorksOn)) {
        stmt.setInt(1, projectId);
        stmt.executeUpdate();
    }

    // If you have Grants referencing ProjectID, remove those here too.

    String sql = "DELETE FROM ResearchProjects WHERE ProjectID = ?";
    try (PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setInt(1, projectId);
        stmt.executeUpdate();
    }
}


    // Insert equipment
    public int addEquipment(String modelName, String equipmentType, String status) throws SQLException {
        // 1) Insert into Equipment and get generated EquipmentID
        String insertEquipSql =
                "INSERT INTO Equipment (Name, Type) VALUES (?, ?)";
        int equipmentId;

        try (PreparedStatement stmt = conn.prepareStatement(
                insertEquipSql,
                Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, modelName);
            stmt.setString(2, equipmentType);
            stmt.executeUpdate();

            try (ResultSet keys = stmt.getGeneratedKeys()) {
                if (!keys.next()) {
                    throw new SQLException("No EquipID generated");
                }
                equipmentId = keys.getInt(1);
            }
        }

        // 2) Insert into Devices, linked to that EquipmentID
        String insertDeviceSql =
                "INSERT INTO Devices (EquipID, Status) VALUES (?, ?)";
        int deviceNumber;

        try (PreparedStatement stmt = conn.prepareStatement(
                insertDeviceSql,
                Statement.RETURN_GENERATED_KEYS)) {

            stmt.setInt(1, equipmentId);
            stmt.setString(2, status);
            stmt.executeUpdate();

            try (ResultSet keys = stmt.getGeneratedKeys()) {
                if (!keys.next()) {
                    throw new SQLException("No DeviceNumber generated");
                }
                deviceNumber = keys.getInt(1);
            }
        }

        return deviceNumber; // this is what you'll show as Device #
    }


    // Update equipment
    public void updateEquipment(int deviceNumber, String modelName, String equipmentType, String status)
            throws SQLException {

        // 1) Find EquipmentID for this device
        Integer equipmentId = null;
        String lookupSql = "SELECT EquipID FROM Devices WHERE DeviceNumber = ?";

        try (PreparedStatement stmt = conn.prepareStatement(lookupSql)) {
            stmt.setInt(1, deviceNumber);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    equipmentId = rs.getInt("EquipID");
                }
            }
        }

        if (equipmentId == null) {
            throw new SQLException("No device found with DeviceNumber=" + deviceNumber);
        }

        // 2) Update Equipment (model name/type)
        String updateEquipSql =
                "UPDATE Equipment SET Name = ?, Type = ? WHERE EquipID = ?";

        try (PreparedStatement stmt = conn.prepareStatement(updateEquipSql)) {
            stmt.setString(1, modelName);
            stmt.setString(2, equipmentType);
            stmt.setInt(3, equipmentId);
            stmt.executeUpdate();
        }

        // 3) Update Devices (status)
        String updateDeviceSql =
                "UPDATE Devices SET Status = ? WHERE DeviceNumber = ?";

        try (PreparedStatement stmt = conn.prepareStatement(updateDeviceSql)) {
            stmt.setString(1, status);
            stmt.setInt(2, deviceNumber);
            stmt.executeUpdate();
        }
    }



    public List<Equipment> listEquipments() throws SQLException {
        List<Equipment> equipments = new ArrayList<>();
        String sql =
                "SELECT d.DeviceNumber, e.Name, e.Type, d.Status " +
                "FROM Devices d " +
                "JOIN Equipment e ON d.EquipID = e.EquipID";

        try (Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Equipment equipment = new Equipment();
                equipment.setEquipmentId(rs.getInt("DeviceNumber"));
                equipment.setModelName(rs.getString("Name"));
                equipment.setType(rs.getString("Type"));
                equipment.setStatus(rs.getString("Status"));
                equipments.add(equipment);
            }
        }
        return equipments;
    }

    public void deleteEquipment(int deviceNumber) throws SQLException {
    // Optional: clean up Uses records for this device
    String deleteUses = "DELETE FROM Uses WHERE DeviceNumber = ?";
    try (PreparedStatement stmt = conn.prepareStatement(deleteUses)) {
        stmt.setInt(1, deviceNumber);
        stmt.executeUpdate();
    }

    String sql = "DELETE FROM Devices WHERE DeviceNumber = ?";
    try (PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setInt(1, deviceNumber);
        stmt.executeUpdate();
    }
}


    public List<EquipmentUsage> listEquipmentUsages() throws SQLException {
        List<EquipmentUsage> equipmentUsages = new ArrayList<>();
        String sql = "SELECT ID, MemberID, DeviceNumber, Purpose FROM USES";
        try (Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                    EquipmentUsage equipmentUsage = new EquipmentUsage();
                    equipmentUsage.setUsageId(rs.getInt("ID"));
                    equipmentUsage.setMemberId(rs.getInt("MemberID"));
                    equipmentUsage.setDeviceNumber(rs.getInt("DeviceNumber"));
                    equipmentUsage.setPurpose(rs.getString("Purpose"));
                    equipmentUsages.add(equipmentUsage);
                }
            }
        return equipmentUsages;
    }

    // Insert equipment usage
    public void addEquipmentUsage(int memberId, int deviceNumber, String purpose) throws SQLException {
        String sql = "INSERT INTO USES (MemberID, DeviceNumber, Purpose) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, memberId);
            stmt.setInt(2, deviceNumber);
            stmt.setString(3, purpose);
            stmt.executeUpdate();
        }
    }

    // Update equipment usage
    public void updateEquipmentUsage(int usageId, int memberId, int deviceNumber, String purpose)
            throws SQLException {
        String sql = "UPDATE USES SET MemberID = ?, DeviceNumber = ?, Purpose = ? WHERE ID = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, memberId);
            stmt.setInt(2, deviceNumber);
            stmt.setString(3, purpose);
            stmt.setInt(4, usageId);
            stmt.executeUpdate();
        }
    }

    public void deleteEquipmentUsage(int usageId) throws SQLException {
    String sql = "DELETE FROM Uses WHERE ID = ?";
    try (PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setInt(1, usageId);
        stmt.executeUpdate();
    }
}


    // 1. Display the status of a project
    public String getProjectStatus(int projectId) throws SQLException {
        String sql = "SELECT Status FROM ResearchProjects WHERE ProjectID = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, projectId);
            ResultSet rs = stmt.executeQuery();
            return rs.next() ? rs.getString("Status") : "Project not found";
        }
    }

    // 2. Show members who worked on projects funded by a given grant
    public List<String> getMembersByGrant(int grantId) throws SQLException {
        List<String> members = new ArrayList<>();
        String sql = "SELECT DISTINCT m.FirstName, m.LastName " +
                "FROM LabMembers m " +
                "JOIN WorksOn w ON m.MemberID = w.MemberID " +
                "JOIN Grants g ON w.ProjectID = g.ProjectID " +
                "WHERE g.GrantID = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, grantId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                members.add(rs.getString("FirstName") + " " + rs.getString("LastName"));
            }
        }
        return members;
    }

    // 3. Show mentorship relations on the same project
    public void printMentorshipByProject() throws SQLException {
        String sql = "SELECT m1.LastName as Mentor, m2.LastName as Mentee, p.Title " +
                "FROM Mentorship mt " +
                "JOIN LabMembers m1 ON mt.MentorMemberID = m1.MemberID " +
                "JOIN LabMembers m2 ON mt.MenteeMemberID = m2.MemberID " +
                "JOIN WorksOn w1 ON m1.MemberID = w1.MemberID " +
                "JOIN WorksOn w2 ON m2.MemberID = w2.MemberID " +
                "JOIN ResearchProjects p ON w1.ProjectID = p.ProjectID " +
                "WHERE w1.ProjectID = w2.ProjectID";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                System.out.println("Project: " + rs.getString("Title") +
                        " | Mentor: " + rs.getString("Mentor") +
                        " -> Mentee: " + rs.getString("Mentee"));
            }
        }
    }
    // 1. Show status of a piece of equipment
    public String getDeviceStatus(int deviceNumber) throws SQLException {
        String sql = "SELECT Status FROM Devices WHERE DeviceNumber = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, deviceNumber);
            ResultSet rs = stmt.executeQuery();
            return rs.next() ? rs.getString("Status") : "Device not found";
        }
    }

    // 2. Show members using equipment and the projects they are working on
    public void showEquipmentUsers(int deviceNumber) throws SQLException {
        String sql =
                "SELECT m.FirstName, m.LastName, p.Title " +
                "FROM Uses u " +
                "JOIN LabMembers m ON u.MemberID = m.MemberID " +
                "JOIN WorksOn w ON m.MemberID = w.MemberID " +
                "JOIN ResearchProjects p ON w.ProjectID = p.ProjectID " +
                "WHERE u.DeviceNumber = ? " +
                "  AND u.EndDate IS NULL";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, deviceNumber);
            try (ResultSet rs = stmt.executeQuery()) {
                boolean any = false;
                while (rs.next()) {
                    any = true;
                    String first = rs.getString("FirstName");
                    String last  = rs.getString("LastName");
                    String title = rs.getString("Title");

                    System.out.println("User: " + first + " " + last +
                            " | Working on: " + title);
                }
                if (!any) {
                    System.out.println("No members are currently using this device.");
                }
            }
        }
    }



    //

        // 1. Top 5 projects ranked by total grant funding
        public void getTop5FundedProjects() throws SQLException {
            String sql =
                    "SELECT TOP 5 p.Title, SUM(g.Budget) AS TotalFunding " +
                    "FROM ResearchProjects p " +
                    "JOIN Grants g ON p.ProjectID = g.ProjectID " +
                    "GROUP BY p.Title, p.ProjectID " +
                    "ORDER BY TotalFunding DESC";

            try (Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {
                System.out.println("--- Top 5 Funded Projects ---");
                while (rs.next()) {
                    System.out.println(rs.getString("Title") + ": $" + rs.getDouble("TotalFunding"));
                }
            }
        }

        // 2. Mentor whose mentees produced the most publications
        public void getTopMentorByMenteePubs() throws SQLException {
            String sql =
                    "SELECT TOP 1 m.FirstName, m.LastName, COUNT(a.PublicID) AS MenteePubs " +
                    "FROM Mentorship mt " +
                    "JOIN LabMembers m ON mt.MentorMemberID = m.MemberID " +
                    "JOIN Author a ON mt.MenteeMemberID = a.MemberID " +
                    "GROUP BY m.MemberID, m.FirstName, m.LastName " +
                    "ORDER BY MenteePubs DESC";

            try (Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {
                System.out.println("--- Top Mentor by Mentee Pubs ---");
                if (rs.next()) {
                    System.out.println("Top Mentor: " + rs.getString("FirstName") + " " +
                            rs.getString("LastName") + " (" + rs.getInt("MenteePubs") + " pubs)");
                }
            }
        }

        // 3. Student publications per major and per year
        public void getStudentPubsByMajorAndYear() throws SQLException {
            String sql =
                    "SELECT s.Major, p.Year, COUNT(a.PublicID) AS TotalPubs " +
                    "FROM Student s " +
                    "JOIN Author a ON s.MemberID = a.MemberID " +
                    "JOIN Publications p ON a.PublicID = p.PublicID " +
                    "GROUP BY s.Major, p.Year " +
                    "ORDER BY s.Major, p.Year";

            try (Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {
                System.out.println("--- Student Pubs by Major & Year ---");
                while (rs.next()) {
                    System.out.println("Major: " + rs.getString("Major") +
                            " | Year: " + rs.getInt("Year") +
                            " | Count: " + rs.getInt("TotalPubs"));
                }
            }
        }

        // 4. Projects ended before date X and their grant counts
        public void getProjectsBeforeDate(String dateX) throws SQLException {
            String sql =
                    "SELECT p.Title, COUNT(g.GrantID) AS GrantCount " +
                    "FROM ResearchProjects p " +
                    "LEFT JOIN Grants g ON p.ProjectID = g.ProjectID " +
                    "WHERE p.EndDate < ? " +
                    "GROUP BY p.ProjectID, p.Title";

            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                // If EndDate is DATE in SQL Server, passing an ISO string 'YYYY-MM-DD' is fine:
                stmt.setString(1, dateX);
                try (ResultSet rs = stmt.executeQuery()) {
                    System.out.println("--- Projects Ended Before " + dateX + " ---");
                    while (rs.next()) {
                        System.out.println(rs.getString("Title") +
                                " | Grants: " + rs.getInt("GrantCount"));
                    }
                }
            }
        }

        // 5. Three most productive years for student publications
        public void getTop3ProductiveYears() throws SQLException {
            String sql =
                    "SELECT TOP 3 p.Year, COUNT(a.PublicID) AS PubCount " +
                    "FROM Publications p " +
                    "JOIN Author a ON p.PublicID = a.PublicID " +
                    "JOIN Student s ON a.MemberID = s.MemberID " +
                    "GROUP BY p.Year " +
                    "ORDER BY PubCount DESC";

            try (Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {
                System.out.println("--- Top 3 Productive Years ---");
                while (rs.next()) {
                    System.out.println("Year: " + rs.getInt("Year") +
                            " | Pubs: " + rs.getInt("PubCount"));
                }
            }
        }

    }



    //


